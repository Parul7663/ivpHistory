﻿using Equities.EquitiesRepo;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using NewProj.Models;
using System.Data;

namespace NewProj.EquitiesRepo
{
    public class BondsTableOps:IBondsTable
    {
        NewcsContext _context;
        

        public BondsTableOps(NewcsContext context)
        {
            _context = context;
        }


        //-----------------------------------------------------------------------------

        //read
        public async Task<List<BondsTable>> GetAllData()
        {
            try
            {
                var data = await _context.BondsTables.ToListAsync();
                return data;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex+" Bonds:getAllData");
                return null; 
            }
            
        }

        public async Task<List<object>> GetBondsTableData(string tableName)
        {
            try
            {
                var results = new List<object>();
                string connectionString = _context.Database.GetConnectionString();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    await conn.OpenAsync();

                    using SqlCommand cmd = new SqlCommand("GetBondsDataByTabName", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@TabName", tableName);

                    using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var record = new Dictionary<string, object>();

                            for (int i = 0; i < reader.FieldCount; i++) //fieldcount = no. of cols
                            {
                                record[reader.GetName(i)] = reader[i]; //getname = colname -> colame:value ......
                            }

                            results.Add(record);
                        }
                    }
                }
                return results;
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex + " Bonds: GetBondsTableData");
                return null;
            }
            
        }
      
        //create
        public async Task<string> AddSecurity(BondsTable table)
        {
            try
            {
                await _context.BondsTables.AddAsync(table);
                int rowsAffected = await _context.SaveChangesAsync();
                if (rowsAffected > 0)
                {
                    return "added successfully";
                }
                return "error while adding";
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex + " Bonds: AddSecurity");
                return null;
            }
            
        }

        //delete
        public async Task<string> DeleteSecurity(string bondName)
        {
            try
            {
                var data = await _context.BondsTables
             .Where(x => x.SecurityName.ToLower() == bondName.ToLower())
             .FirstOrDefaultAsync();

                if (data != null)
                {
                    _context.BondsTables.Remove(data); // Pass the entity, not the ID
                    await _context.SaveChangesAsync(); // Save changes to the database
                    return "Bond deleted successfully";
                }
                return null;
            }
            catch (Exception ex) {
                Console.WriteLine(ex + " Bonds: DeleteSecurity");
                return null;
            }  
        }

        public async Task<string> UpdateSecurityById(BondsTable table)
        {
            try
            {
                var existingBond = await _context.BondsTables.FindAsync(table.SecurityId);
                if (existingBond == null)
                {
                    return "Bond not found";
                }
                existingBond.SecurityDescription = table.SecurityDescription;
                existingBond.SecurityName = table.SecurityName;
                existingBond.AssetType = table.AssetType;
                existingBond.InvestmentType = table.InvestmentType;
                existingBond.TradingFactor = table.TradingFactor;
                existingBond.PricingFactor = table.PricingFactor;
                existingBond.Isin = table.Isin;
                existingBond.BloombergTicker = table.BloombergTicker;
                existingBond.BloombergUniqueId = table.BloombergUniqueId;
                existingBond.Cusip = table.Cusip;
                existingBond.Sedol = table.Sedol;
                existingBond.FirstCouponDate = table.FirstCouponDate;
                existingBond.CouponCap = table.CouponCap;
                existingBond.CouponFloor = table.CouponFloor;
                existingBond.CouponFrequency = table.CouponFrequency;
                existingBond.CouponRate = table.CouponRate;
                existingBond.CouponType = table.CouponType;
                existingBond.FloatSpread = table.FloatSpread;
                existingBond.IsCallable = table.IsCallable;
                existingBond.IsFixToFloat = table.IsFixToFloat;
                existingBond.IsPutable = table.IsPutable;
                existingBond.IssueDate = table.IssueDate;
                existingBond.LastResetDate = table.LastResetDate;
                existingBond.MaturityDate = table.MaturityDate;
                existingBond.MaximumCallNoticeDays = table.MaximumCallNoticeDays;
                existingBond.MaximumPutNoticeDays = table.MaximumPutNoticeDays;
                existingBond.PenultimateCouponDate = table.PenultimateCouponDate;
                existingBond.ResetFrequency = table.ResetFrequency;
                existingBond.HasPosition = table.HasPosition;
                existingBond.Duration = table.Duration;
                existingBond.Volatility30D = table.Volatility30D;
                existingBond.Volatility90D = table.Volatility90D;
                existingBond.Convexity = table.Convexity;
                existingBond.AverageVolume30D = table.AverageVolume30D;
                existingBond.FormPfassetClass = table.FormPfassetClass;
                existingBond.FormPfcountry = table.FormPfcountry;
                existingBond.FormPfcreditRating = table.FormPfcreditRating;
                existingBond.FormPfcurrency = table.FormPfcurrency;
                existingBond.FormPfinstrument = table.FormPfinstrument;
                existingBond.FormPfliquidityProfile = table.FormPfliquidityProfile;
                existingBond.FormPfmaturity = table.FormPfmaturity;
                existingBond.FormPfnaicscode = table.FormPfnaicscode;
                existingBond.FormPfregion = table.FormPfregion;
                existingBond.FormPfsector = table.FormPfsector;
                existingBond.FormPfsubAssetClass = table.FormPfsubAssetClass;
                existingBond.BloombergIndustryGroup = table.BloombergIndustryGroup;
                existingBond.BloombergIndustrySubGroup = table.BloombergIndustrySubGroup;
                existingBond.BloombergSector = table.BloombergSector;
                existingBond.IssueCountry = table.IssueCountry;
                existingBond.IssueCurrency = table.IssueCurrency;
                existingBond.Issuer = table.Issuer;
                existingBond.RiskCurrency = table.RiskCurrency;
                existingBond.PutDate = table.PutDate;
                existingBond.PutPrice = table.PutPrice;
                existingBond.AskPrice = table.AskPrice;
                existingBond.HighPrice = table.HighPrice;
                existingBond.LowPrice = table.LowPrice;
                existingBond.OpenPrice = table.OpenPrice;
                existingBond.Volume = table.Volume;
                existingBond.BidPrice = table.BidPrice;
                existingBond.LastPrice = table.LastPrice;
                existingBond.CallDate = table.CallDate;
                existingBond.CallPrice = table.CallPrice;

                await _context.SaveChangesAsync();
                return "Updated";
            }
            catch (Exception ex) {
                Console.WriteLine(ex + " Bonds: AddSecurity");
                return null;
            }
            
        }


        public async Task<BondsTable> getSecByName(string bondName)
        {
            try
            {
                var data = await _context.BondsTables.Where(x => x.SecurityName.ToLower() == bondName.ToLower()).FirstOrDefaultAsync();
                return data;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex + " Bonds: AddSecurity");
                return null;
            }
           
        }

    }
}
