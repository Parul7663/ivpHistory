﻿//using Equities.Controllers;

using Microsoft.AspNetCore.JsonPatch;
using NewProj.Models;

namespace Equities.EquitiesRepo
{
    public interface IEquityTab
    {
        public Task<List<Etab>>  GetAllTableNames();
        public Task<Etab> GetTabById(int id);
        public Task<string> AddTable(Etab tab);
        public Task<string> UpdateTableName(int id , JsonPatchDocument patch);
        public Task<string> RemoveTable(int id );
    }
}
