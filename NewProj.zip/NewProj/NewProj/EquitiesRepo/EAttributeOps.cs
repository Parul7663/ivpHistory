﻿

using Microsoft.AspNetCore.JsonPatch;
using Microsoft.EntityFrameworkCore;
using NewProj.Models;

namespace Equities.EquitiesRepo
{
    public class EAttributeOps : IEAttribute
    {
        NewcsContext _context;
        public EAttributeOps(NewcsContext context)
        {
            _context = context;
        }

        //-----------------------------------------------------------------------------
        public async Task<List<Eattribute>> GetAllAttributeNames()
        {
            var AttributeNames = await _context.Eattributes.ToListAsync();
            return AttributeNames;
        }

        public async Task<Eattribute> GetAttributeById(int id)
        {
            return await _context.Eattributes.FindAsync(id);
        }

        public async Task<string> AddAttribute(Eattribute att)
        {
            await _context.Eattributes.AddAsync(att);
            await _context.SaveChangesAsync();
            return "Attribute Inserted Successfuly";
        }
        public async Task<string> UpdateAttributeName(int id, JsonPatchDocument patch)
        {
            var data = await _context.Eattributes.FindAsync(id);
            if (data != null)
            {
                patch.ApplyTo(data);
                await _context.SaveChangesAsync();
                return "attribute name updated sucessfulyy";
            }
            return "wrong attribute id";
        }
        public async Task<string> RemoveAttribute(int id)
        {
            var data = await _context.Eattributes.FindAsync(id);
            if (data != null)
            {
                _context.Eattributes.Remove(data);
                await _context.SaveChangesAsync();
                return $"{id}-attribute deleted sucessfully ";
            }
            return "please enter a valid attribute id";
        }
        public async Task<List<string>> GetAttributeNamesByTableId(int tableId)
        {
            var data = await _context.Eattributes
               .Where(e => e.TabId == tableId)
               .Select(e => e.AttName) 
               .ToListAsync();
            return data;
        }
    }
}
