﻿

using Microsoft.AspNetCore.JsonPatch;
using Microsoft.EntityFrameworkCore;
using NewProj.Models;
//using JsonPatchDocument = Microsoft.AspNetCore.JsonPatch.JsonPatchDocument;

namespace Equities.EquitiesRepo
{
    public class EtabOps:IEquityTab
    {
        NewcsContext _context;

        public EtabOps(NewcsContext context)
        {
            _context = context;

        }
        //-----------------------------------------------------------------------------
        public async Task<List<Etab>> GetAllTableNames()
        {
            var tableNames = await _context.Etabs.ToListAsync();
            Console.WriteLine(tableNames);
            return tableNames;
        }
        public async Task<Etab> GetTabById(int id)
        {
            return await _context.Etabs.FindAsync(id);
        }
        public async Task<string> AddTable(Etab tab)
        {
            await _context.Etabs.AddAsync(tab);
            _context.SaveChangesAsync();
            return "Table Inserted Successfuly";
        }
        public async Task<string> UpdateTableName(int id, JsonPatchDocument patch)
        {
            var data = await _context.Etabs.FindAsync(id);
            if(data !=null)
            {
                patch.ApplyTo(data);
                await _context.SaveChangesAsync();
                return "table name updated sucessfulyy";
            }
            return "wrong table id";

        }

        public async Task<string> RemoveTable(int id)
        {
            var data = await _context.Etabs.FindAsync(id);
            if (data != null)
            {
               _context.Etabs.Remove(data);
               await _context.SaveChangesAsync();
               return $"{id} deleted sucessfully ";
            }
            return "please enter a valid table id";
        }

    }
}

