﻿using NewProj.Models;

namespace NewProj.EquitiesRepo
{
    public interface IBondsTable
    {
        public Task<List<BondsTable>> GetAllData();

        public Task<List<object>> GetBondsTableData(string tableName);

        public Task<string> AddSecurity(BondsTable table);

        public Task<string> DeleteSecurity(string bondName);

        public Task<string> UpdateSecurityById( BondsTable table);

        public Task<BondsTable> getSecByName(string bondName);
    }
}
