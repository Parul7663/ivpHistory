﻿
using NewProj.Models;

namespace Equities.EquitiesRepo
{
    public interface IEquityTable
    {
        public Task<List<EquityTable>> GetAllData();

        public Task<List<object>> GetTableData(string tableName);

        public Task<EquityTable> GetSecByName(string secName);   

        public Task<string> AddSecurity(EquityTable table);

        public Task<string> DeleteSecurity(int secId);

        public Task<string> UpdateSecurityById( EquityTable table);

        public Task<EquityTable> getSecById(int secId);

        //public Task<string> UpdatSecuritySummary(EquityTable table, int secId);

    }


}
