﻿

using Microsoft.AspNetCore.JsonPatch;
using NewProj.Models;

namespace Equities.EquitiesRepo
{
    public interface IEAttribute
    {
        public Task<List<Eattribute>> GetAllAttributeNames();
        public Task<List<string>> GetAttributeNamesByTableId(int tableId);
        public Task<Eattribute> GetAttributeById(int id);
        public Task<string> AddAttribute(Eattribute att);
        public Task<string> UpdateAttributeName(int id, JsonPatchDocument patch);
        public Task<string> RemoveAttribute(int id);


       
    }
}
