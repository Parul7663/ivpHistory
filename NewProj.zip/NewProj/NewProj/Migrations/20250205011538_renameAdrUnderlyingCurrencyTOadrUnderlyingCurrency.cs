﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NewProj.Migrations
{
    /// <inheritdoc />
    public partial class renameAdrUnderlyingCurrencyTOadrUnderlyingCurrency : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "AdrUnderlyingCurrency",
                table: "EquityTable",
                newName: "adrUnderlyingCurrency");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "adrUnderlyingCurrency",
                table: "EquityTable",
                newName: "adrUnderlyingCurrency");
        }
    }
}
