﻿using System;
using System.Collections.Generic;

namespace NewProj.Models;

public partial class Eattribute
{
    public int AttId { get; set; }

    public string? AttName { get; set; }

    public int? TabId { get; set; }

    public virtual Etab? Tab { get; set; }
}
