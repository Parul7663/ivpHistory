﻿using System;
using System.Collections.Generic;

namespace NewProj.Models;

public partial class Battribute
{
    public int AttId { get; set; }

    public string? AttName { get; set; }

    public int? TabId { get; set; }

    public virtual Btab? Tab { get; set; }
}
