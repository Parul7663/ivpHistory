﻿using System;
using System.Collections.Generic;

namespace NewProj.Models;

public partial class Etab
{
    public int TabId { get; set; }

    public string? TabName { get; set; }

    public virtual ICollection<Eattribute> Eattributes { get; set; } = new List<Eattribute>();
}
