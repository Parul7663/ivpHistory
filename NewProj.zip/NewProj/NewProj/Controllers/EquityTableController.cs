﻿

using Equities.EquitiesRepo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.Language;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using NewProj.Models;

namespace Equities.Controllers
{

    [Route("Equity/[controller]")]
    [ApiController]
    public class EquityTableController:ControllerBase
    {
        IEquityTable _eq;
        public EquityTableController(IEquityTable eq)
        {
            _eq = eq;
        }

        [HttpGet("get")]
        public async Task<IActionResult> GetAllData()
        {
            var info = await _eq.GetAllData();
            if (info == null)
            {
                return NotFound();
            }
            return Ok(info);
        }

        [HttpGet("getData/{tableName}")]  
        public async Task<IActionResult> GetTabData([FromRoute]string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName))
                return BadRequest();

            var info = await _eq.GetTableData(tableName);
            if (info == null)
            {
                return NotFound();
            }
            return Ok(info);
        }

      
    

        [HttpPost("addSecurity")]
        public async Task<IActionResult> AddSec([FromBody]EquityTable table)
        {
            if (table == null)
            {
                return BadRequest();
            }
            else
            {
                var str = await _eq.AddSecurity(table);
                if(str!=null)
                    return Ok(str);
                return BadRequest();
            }
        }


        //[HttpGet("getSecById/{secId:int}")]
        [HttpGet("getSecById/{secId}")]
        public async Task<IActionResult> getSecById([FromRoute] int secId)
        {
            if (secId == null || secId<0) 
            { return BadRequest(); }

            var res = await _eq.getSecById(secId);
            if (res != null)
            {
                return Ok(res);
            }
            return NotFound();
        }

        //[HttpDelete("delete/{secId:int}")]
        [HttpDelete("delete/{secId}")]
        public async Task<IActionResult> DelSecurity([FromRoute]int secId)
        {
            if(secId < 0 || secId == null)
            {
                return BadRequest();
            }
            else
            {
                var str = await _eq.DeleteSecurity(secId);
                if (str != null)
                    return Ok(str);
                return BadRequest();
               
            }
        }


        [HttpPut("UpdateEquity")]
        public async Task<IActionResult> UpdatSecById([FromBody]EquityTable table)
        {
            if (table == null)
            { return BadRequest(); }

            var str = await _eq.UpdateSecurityById(table);
            if (str != null)
                return Ok(str);
            return BadRequest("Equity Not Found");
            
        }


        [HttpGet("getSecByName/{secName}")]
        public async Task<IActionResult> getSecByName([FromRoute] string secName)
        {
            if (secName == null || secName=="")
            { return BadRequest(); }

            var res = await _eq.GetSecByName(secName);
            if (res != null)
            {
                return Ok(res);
            }
            return NotFound();
        }

    }
}
