﻿
using Equities.EquitiesRepo;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.Language;
using NewProj.Models;

namespace Equities.Controllers
{
    [Route("Equity/[controller]")]
    [ApiController]
    public class EAttributeController:ControllerBase
    {
        IEAttribute _eq;
        public EAttributeController(IEAttribute eq)
        {
            _eq = eq;
        }

        //-------------------------------------------------------------
        [HttpGet("get")]
        public async Task<IActionResult> GetAllTabs()
        {
            var info = await _eq.GetAllAttributeNames();
            if (info == null)
            {
                return NotFound();
            }
            return Ok(info);
        }

        [HttpGet("get/{id}")]
        public async Task<IActionResult> GetAttById([FromRoute] int id)
        {
            var attDetails = await _eq.GetAttributeById(id);
            if (attDetails == null)
            {
                return NotFound();
            }
            return Ok(attDetails.TabId);
        }
        [HttpGet("getAttributeByTableId/{id}")]
        public async Task<IActionResult> GetTableAttByTableId([FromRoute] int id)
        {
            var attDetails = await _eq.GetAttributeNamesByTableId(id);
            if (attDetails == null)
            {
                return NotFound();
            }
            return Ok(attDetails);
        }

        //------------------------------------------------------------------------------
        [HttpPost("post")]
        public async Task<IActionResult> AddAtt([FromBody] Eattribute att)
        {
            string str = await _eq.AddAttribute(att);
            if (string.IsNullOrEmpty(str))
            {
                return BadRequest("atribute could not be added.");
            }
            //return Ok(str);
            return CreatedAtAction(nameof(GetAttById), new { id = att.AttId }, att);
        }

        //------------------------------------------------------------------------------
        [HttpPatch("patch/{id}")]
        public async Task<IActionResult> UpdateTName([FromRoute] int id, JsonPatchDocument patch)
        {
            string str = await _eq.UpdateAttributeName(id, patch);
            return Ok(str);
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> delAtt([FromRoute] int id)
        {
            string str = await _eq.RemoveAttribute(id);
            return Ok(str);
        }


    }
}
