﻿using Equities.EquitiesRepo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using NewProj.EquitiesRepo;
using NewProj.Models;


namespace NewProj.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BondsController : ControllerBase
    {
        IBondsTable _eq;
        public BondsController(IBondsTable eq)
        {
            _eq = eq;
        }

        [HttpGet("get")]
        public async Task<IActionResult> GetAllData()
        {
            var info = await _eq.GetAllData();
            if (info == null)
            {
                return NoContent();
            }
            return Ok(info);
        }

        [HttpGet("getData/{tableName}")]
        public async Task<IActionResult> GetTabData([FromRoute] string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName))
                return BadRequest();


            var info = await _eq.GetBondsTableData(tableName);
            if (info == null)
            {
                return NotFound();
            }
            return Ok(info);
        }


        [HttpPost("addBond/")]
        public async Task<IActionResult> AddSec([FromBody] BondsTable table)
        {
            if (table == null)
            {
                return BadRequest();
            }
            else
            {
                var str = await _eq.AddSecurity(table);
                if (str != null) { 
                 return Ok(str);
                }
               return BadRequest();
            }
        }

        [HttpDelete("deleteBondByName/{bondName}")]
        public async Task<IActionResult> DelSecurity([FromRoute] string bondName)
        {
            if (string.IsNullOrWhiteSpace(bondName))
                return BadRequest();


            var str = await _eq.DeleteSecurity(bondName);
            if (str != null)
            {
                return Ok(str);
            }
            return NotFound();
            
        }


        //[HttpPut("UpdateSecuritySummary/")]
        //public async Task<IActionResult> UpdatSecById( [FromBody] BondsTable table)
        //{
        //    var str = await _eq.UpdateSecurityById(table);
        //    return Ok(str);
        //}

        [HttpPut("UpdateBond/")]
        public async Task<IActionResult> UpdatSecById([FromBody] BondsTable table)
        {
            if (table == null) { return BadRequest(); }

            var str = await _eq.UpdateSecurityById(table);
            if (str != null)
            {
                return Ok(str);
            }
            return BadRequest();
        }

        [HttpGet("getBondByName/{bondName}")]
        public async Task<IActionResult> getSecByName([FromRoute] string bondName)
        {
            if (string.IsNullOrWhiteSpace(bondName)) 
                return BadRequest();


            var res = await _eq.getSecByName(bondName);
            if (res != null)
                return Ok(res);  
            return NotFound();
        }

    }
}
