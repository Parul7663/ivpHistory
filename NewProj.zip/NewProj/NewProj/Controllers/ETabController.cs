﻿
using Equities.EquitiesRepo;
using Microsoft.AspNetCore.JsonPatch ;
using Microsoft.AspNetCore.Mvc;
using NewProj.Models;

namespace Equities.Controllers
{

    [Route("Equity/[controller]")]
    [ApiController]
    public class ETabController : ControllerBase
    {
        IEquityTab _eq;
        public ETabController(IEquityTab eq)
        {
            _eq = eq;
        }
        //-------------------------------------------------------------
        [HttpGet("get")]
        public async Task<IActionResult> GetAllTabs()
        {
            var info = await _eq.GetAllTableNames();
            if (info == null)
            {
                return NotFound();
            }
            return Ok(info);
        }
        [HttpGet("get/{id}")]
        public async Task<IActionResult> GetTableById([FromRoute] int id)
        {
            var tableDetails = await _eq.GetTabById(id);
            if (tableDetails == null)
            {
                return NotFound();
            }
            return Ok(tableDetails.TabId);
        }
        //------------------------------------------------------------------------------
        [HttpPost("post")]
        public async Task<IActionResult> AddTable([FromBody] Etab tab)
        {
            string str = await _eq.AddTable(tab);
            if (string.IsNullOrEmpty(str))
            {
                return BadRequest("Table could not be added.");
            }
            //return Ok(str);
            return CreatedAtAction(nameof(GetTableById), new { id = tab.TabId }, tab);
        }
        //------------------------------------------------------------------------------
        [HttpPatch("patch/{id}")]
        public async Task<IActionResult> UpdateTName([FromRoute] int id, JsonPatchDocument patch)
        {
            string str = await _eq.UpdateTableName(id, patch);
            return Ok(str);
        }
         [HttpDelete("delete/{id}")]
        public async Task<IActionResult> delTable([FromRoute] int id)
        {
            string str = await _eq.RemoveTable(id);
            return Ok(str);
        }

    }
}
