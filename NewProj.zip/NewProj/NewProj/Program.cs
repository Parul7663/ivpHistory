
using System.Configuration;
using System.Reflection.Emit;
using Equities.EquitiesRepo;
using Microsoft.EntityFrameworkCore;
using NewProj.EquitiesRepo;
using NewProj.Models;
using Serilog;

namespace NewProj
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(builder.Configuration)
            .Enrich.FromLogContext()
            .WriteTo.Console()
            .WriteTo.File("C:\\Users\\pmehra\\Desktop\\logs\\NewProjLog.txt")
            .CreateLogger();
            builder.Host.UseSerilog();
            


            // Add services to the container.
            var configuration = builder.Configuration;
            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddDbContext<NewcsContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("connstr")));

            //builder.Services.AddTransient<IEquityTab, EtabOps>();
            //builder.Services.AddTransient<IEAttribute, EAttributeOps>();
            //builder.Services.AddTransient<IEquityTable, EquityTableOps>();

            //addtransient -> for every get/put/post req new ops obj make->new context made -> new conn established ->pb BAD
            //addscoped -> for every get/put/post req 1 ops obj make-> 1 new context made -> new conn established only 1time GOOD   

            builder.Services.AddScoped<IEquityTab, EtabOps>();
            builder.Services.AddScoped<IEAttribute, EAttributeOps>();
            builder.Services.AddScoped<IEquityTable, EquityTableOps>();


            builder.Services.AddScoped<IBondsTable, BondsTableOps>();
           


            builder.Services.AddCors(options =>
            {
                options.AddPolicy("NewProj", builder =>
                {
                    builder.WithOrigins("http://localhost:3000", "http://localhost:3001").AllowAnyHeader().AllowAnyMethod();
                });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.UseCors("NewProj");

            app.MapControllers();

            app.Run();
        }
    }
}
